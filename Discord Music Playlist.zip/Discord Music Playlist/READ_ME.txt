SongList.txt contains a list of your songs, and must remain in the same folder as the Discord Playlist App.

Once you've created a playlist, Select the discord music bot you are using. Then click the Play Playlist button, and quickly click
to enter a message into a discord channel that the music bot has access to. After 3 seconds of clickling the Play Playlist button
commands will be typed out to search for the each of the songs within your playlist, in a random order.

Currently works for:
-Hydra
-FredBoat
-Probot